# -*- coding: utf-8 -*-
"""
Created on Fri Dec 28 16:23:00 2018

@author: RTR
"""

import pandas as pd
import numpy as np
from pandas import Series

df1=pd.read_excel("C:\\Users\\RTR\\Desktop\\python\\kaleidofin_internshala_assignment\\Assignment_1 2\\chit fund exercise.xlsx")
df1.columns

new_Series = Series(- df1.Contribution + df1["Amount returned to everyone in the group"])
#print(new_Series)
second_Series =  df1["Net amount recd by Bid winner"]    
#print(second_Series)
third_Series=[]
for i in second_Series:
    #print(i)
    third_Series.append(i)
    for j in new_Series:
        third_Series.append(j) 
        #print(j)
    irr_Final = round(np.irr(third_Series), 25)
    print(irr_Final)
#print(third_Series)